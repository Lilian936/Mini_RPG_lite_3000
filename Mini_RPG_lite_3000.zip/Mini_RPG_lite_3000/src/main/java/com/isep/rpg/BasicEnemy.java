package com.isep.rpg;

public class BasicEnemy extends Enemy{
    public BasicEnemy(String name,int lifePoints, String type, int armor, int damage) {
        super(name,lifePoints, type, armor, damage);
    }
}
