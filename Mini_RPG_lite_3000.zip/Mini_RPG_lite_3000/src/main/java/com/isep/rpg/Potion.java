package com.isep.rpg;

public class Potion extends Consumable {
    public Potion(String name, int lifepoints, int manapoints, String type) {
        super(name, lifepoints, manapoints, "Potion");
    }
}
