package com.isep.rpg;

public class Boss extends Enemy{
    public Boss(String name,int lifePoints, String type, int armor, int damage) {
        super(name,lifePoints, type, armor, damage);
    }
}
